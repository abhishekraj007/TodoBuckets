export const CREATE_BUCKET = "CREATE_BUCKET";
export const EDIT_BUCKET = "EDIT_BUCKET";
export const DELETE_BUCKET = "DELETE_BUCKET";

export const ADD_TODO = "ADD_TODO";
export const EDIT_TODO = "EDIT_TODO";
export const DELETE_TODO = "DELETE_TODO";
export const COMPLETE_TODO = "COMPLETE_TODO";
